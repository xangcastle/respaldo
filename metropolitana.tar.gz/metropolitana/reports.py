# -*- coding: utf-8 -*-
#import reporting
from django.db.models import Sum, Avg, Count
from .models import *


#class colector_report(reporting.Report):
    #model = Colector
    #verbose_name = 'Reporte por Colector'
    #annotate = (
            #('', ''),
        #)