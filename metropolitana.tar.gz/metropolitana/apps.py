# -*- coding: utf-8 -*-
from django.apps import AppConfig


class MetropolitanaConfig(AppConfig):
    name = 'metropolitana'
    verbose_name = "Distribucion y Entregas"