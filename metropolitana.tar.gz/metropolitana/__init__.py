# -*- coding: utf-8 -*-
default_app_config = 'metropolitana.apps.MetropolitanaConfig'